document.addEventListener("DOMContentLoaded", () => {
  const apiUrl = "/api";
  const sceneList = document.getElementById("scene-list");
  const addSceneBtn = document.getElementById("add-scene");
  const sceneNameInput = document.getElementById("scene-name-input");

  let lastKnownColors = {};
  const colorPickers = {};

  const deviceConfigs = {
    "wled_device": {
      pickerId: "#wled-color-picker",
      toggleId: "#wled-toggle",
      type: "WLED",
      expandBtn: "#wled-expand",
      slidersContainer: "#wled-sliders",
      colorButtons: ".color-btn[data-device='wled_device']"
    },
    "tasmota2_device": {
      pickerId: "#tasmota2-color-picker",
      toggleId: "#tasmota2-toggle",
      type: "Tasmota2",
      expandBtn: "#tasmota2-expand",
      slidersContainer: "#tasmota2-sliders",
      colorButtons: ".color-btn[data-device='tasmota2_device']"
    },
    "openbeken_device": {
      pickerId: "#openbeken-color-picker",
      toggleId: "#openbeken-toggle",
      type: "Openbeken",
      expandBtn: "#openbeken-expand",
      slidersContainer: "#openbeken-sliders",
      colorButtons: ".color-btn[data-device='openbeken_device']"
    }
  };

  fetch(`${apiUrl}/status`)
    .then(res => res.json())
    .then(statusData => {
      initDeviceControls(statusData);
      renderScenes();
    });

  function initDeviceControls(statusData) {
    Object.entries(deviceConfigs).forEach(([deviceId, config]) => {
      const pickerElement = document.querySelector(config.pickerId);
      const toggleButton = document.querySelector(config.toggleId);
      const expandButton = document.querySelector(config.expandBtn);
      const sliderContainer = document.querySelector(config.slidersContainer);
      const colorButtons = document.querySelectorAll(config.colorButtons);

      const colorPicker = new iro.ColorPicker(config.pickerId, {
        width: 300,
        layoutDirection: "vertical",
        layout: [
          { component: iro.ui.Slider, options: { sliderType: 'hue' } },
          { component: iro.ui.Slider, options: { sliderType: 'saturation' } },
          { component: iro.ui.Slider, options: { sliderType: 'value' } }
        ],
        padding: 10,
        handleRadius: 6
      });

      colorPickers[deviceId] = colorPicker;

      const status = statusData[deviceId];
      if (status) {
        const [r, g, b] = status.color.split(",").map(Number);
        const isOn = status.power === "ON";
        lastKnownColors[deviceId] = { r, g, b };
        colorPicker.color.rgb = { r, g, b };
        updateToggleVisual(deviceId, isOn, isOn ? { r, g, b } : null);
        toggleButton.classList.toggle("active", isOn);
      }

      toggleButton.addEventListener("click", () => {
        sendToggleCommand(deviceId, toggleButton);
        const isNowOn = !toggleButton.classList.contains("active");
        toggleButton.classList.toggle("active", isNowOn);
      });

      expandButton.addEventListener("click", () => {
	    if (window.innerWidth < 768) {
	      sliderContainer.classList.toggle("active");
		  const icon = expandButton.querySelector("img");
		  icon.src = sliderContainer.classList.contains("active") ? "assets/up.svg" : "assets/down.svg";
		}
	  });


      colorPicker.on("color:change", (color) => {
        const rgb = color.rgb;
        const brightness = color.value;

        lastKnownColors[deviceId] = rgb;
        sendColor(deviceId, rgb);
        sendBrightness(deviceId, brightness);

        const toggle = document.querySelector(config.toggleId);
        toggle.classList.add("active");
        updateToggleVisual(deviceId, true, rgb);
        sendPower(deviceId, 1);
      });

      // Load saved colors
      const savedPresets = JSON.parse(localStorage.getItem("presetColors") || "{}");
      if (savedPresets[deviceId]) {
        savedPresets[deviceId].forEach((hex, index) => {
          if (colorButtons[index]) {
            colorButtons[index].style.backgroundColor = hex;
          }
        });
      }

      // Add short + long press handlers
      colorButtons.forEach((btn, index) => {
        let pressTimer;

        const start = () => {
          pressTimer = setTimeout(() => {
            const currentColor = colorPickers[deviceId].color.hexString;
            btn.style.backgroundColor = currentColor;

            if (!savedPresets[deviceId]) savedPresets[deviceId] = [];
            savedPresets[deviceId][index] = currentColor;
            localStorage.setItem("presetColors", JSON.stringify(savedPresets));

            btn.classList.add("flash");
            setTimeout(() => btn.classList.remove("flash"), 300);

          }, 500);
        };

        const cancel = () => clearTimeout(pressTimer);

        btn.addEventListener("mousedown", start);
        btn.addEventListener("touchstart", start);
        btn.addEventListener("mouseup", cancel);
        btn.addEventListener("mouseleave", cancel);
        btn.addEventListener("touchend", cancel);

        btn.addEventListener("click", () => {
          if (pressTimer) {
            cancel();
            const style = window.getComputedStyle(btn);
            const [r, g, b] = style.backgroundColor.match(/\d+/g).map(Number);

            colorPicker.color.rgb = { r, g, b };
            colorPicker.color.value = 100;

            sendColor(deviceId, { r, g, b });
            sendBrightness(deviceId, 100);
            sendPower(deviceId, 1);
            updateToggleVisual(deviceId, true, { r, g, b });
          }
        });
      });
    });
  }

function updateToggleVisual(deviceId, isOn, color = null) {
  const toggle = document.querySelector(deviceConfigs[deviceId].toggleId);
  toggle.classList.toggle("active", isOn);
  toggle.style.color = isOn && color ? `rgb(${color.r}, ${color.g}, ${color.b})` : "#555";

  const ovalMap = {
    "wled_device": "oval-wled",
    "tasmota2_device": "oval-tasmota2",
    "openbeken_device": "oval-openbeken"
  };

  const ovalId = ovalMap[deviceId];
  if (ovalId) {
    const oval = document.getElementById(ovalId);
    if (oval) {
      oval.style.backgroundColor = isOn && color ? `rgb(${color.r}, ${color.g}, ${color.b})` : "transparent";
    }
  }
}
	
	function sendToggleCommand(deviceId, buttonElement) {
		const isNowOn = !buttonElement.classList.contains("active");
		const newPowerState = isNowOn ? "ON" : "OFF";

		fetch("/api/control", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				device: deviceId,
				command: newPowerState,
				command_type: "POWER"
			})
		})
		.then(res => res.json())
		.then(data => {
			if (data.success) {
				buttonElement.classList.toggle("active", isNowOn);

				//oval + power button
				const color = isNowOn ? lastKnownColors[deviceId] : null;
				updateToggleVisual(deviceId, isNowOn, color);

				if (!devicePowerState) devicePowerState = {};
				devicePowerState[deviceId] = newPowerState;
			}
		});
	}

  function sendPower(deviceId, on) {
    fetch("/api/control", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device: deviceId,
        command: on ? 1 : 0,
        command_type: "POWER"
      })
    });
  }

  function sendColor(deviceId, color) {
    const command = `${color.r},${color.g},${color.b}`;
    fetch("/api/control", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device: deviceId,
        command,
        command_type: "COLOR"
      })
    });
  }

  function sendBrightness(deviceId, value) {
    fetch("/api/control", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device: deviceId,
        command: Math.round(value),
        command_type: "DIMMER"
      })
    });
  }

  function applyScene(name) {
    fetch("/api/apply_scene", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scene_name: name })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success && data.devices) {
       Object.entries(data.devices).forEach(([deviceId, state]) => {
          const color = state.color;
          const power = state.power === "ON";

        // Update last known color
          lastKnownColors[deviceId] = color;

        // Update color picker
          if (colorPickers[deviceId]) {
            colorPickers[deviceId].color.rgb = color;
          }

          // Update toggle button
          const toggle = document.querySelector(deviceConfigs[deviceId].toggleId);
          toggle.classList.toggle("active", power);
          updateToggleVisual(deviceId, power, color);
        });
      }
    });
  }

  function deleteScene(name) {
    fetch(`/api/scenes/${encodeURIComponent(name)}`, { method: "DELETE" })
      .then(() => renderScenes());
  }

  function createSceneButton(scene) {
    const item = document.createElement("div");
    item.className = "scene-item";

    const span = document.createElement("span");
    span.innerText = scene.name;
    span.addEventListener("click", () => applyScene(scene.name));

    const delBtn = document.createElement("button");
    delBtn.className = "delete-scene";
    const icon = document.createElement("img");
    icon.src = "/assets/trash.svg";
    icon.alt = "Delete";
    icon.classList.add("trash-icon");
    delBtn.appendChild(icon);
    delBtn.addEventListener("click", e => {
      e.stopPropagation();
      deleteScene(scene.name);
    });

    item.appendChild(span);
    item.appendChild(delBtn);
    sceneList.appendChild(item);
  }

  function renderScenes() {
    fetch("/api/scenes")
      .then(res => res.json())
      .then(data => {
        sceneList.innerHTML = "";
        data.forEach(createSceneButton);
      });
  }

	addSceneBtn.addEventListener("click", () => {
		const name = sceneNameInput.value.trim();
		if (!name) return;

		const devices = {};

		Object.entries(deviceConfigs).forEach(([deviceId, config]) => {
			const toggle = document.querySelector(config.toggleId);
			const isOn = toggle?.classList.contains("active") ?? false;
			const color = lastKnownColors[deviceId];

			// Start device object with power
			const deviceState = {
				power: isOn ? "ON" : "OFF"
			};

			// Only save color and brightness if the device is ON
			if (isOn && color) {
				deviceState.color = color;
				deviceState.brightness = 100; // Replace if you track this per device
			}

			devices[deviceId] = deviceState;
		});

		fetch("/api/scenes", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ name, devices })
		}).then(() => {
			sceneNameInput.value = "";
			renderScenes();
		});
	});

  const tutorialBtn = document.getElementById("tutorial");
  const popup = document.getElementById("popup");
  const closeBtn = popup.querySelector(".close-btn");

  tutorialBtn.addEventListener("click", () => {
    popup.classList.remove("hidden");
  });

  closeBtn.addEventListener("click", () => {
    popup.classList.add("hidden");
  });

  window.addEventListener("click", (e) => {
    if (e.target === popup) popup.classList.add("hidden");
  });
  
  const demoBtn = document.getElementById("demo-video");
  demoBtn.addEventListener("click", () => {
    window.open("assets/demo.mp4", "_blank");
  });

});
