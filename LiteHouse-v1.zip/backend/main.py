import json
import os
import time

# Path to store scenes
SCENES_FILE = "scenes.json"

# Ensure scenes.json exists
if not os.path.exists(SCENES_FILE):
    with open(SCENES_FILE, "w") as file:
        json.dump([], file, indent=4)

def load_scenes(file_path=SCENES_FILE):
    try:
        with open(file_path, "r") as file:
            scenes = json.load(file)
        scenes_sorted = sorted(scenes, key=lambda scene: scene["name"].lower())    
        return scenes_sorted
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []

def save_scenes(scenes, file_path=SCENES_FILE):
    with open(file_path, "w") as file:
        json.dump(scenes, file, indent=4)

def delete_scene(name, file_path=SCENES_FILE):
    scenes = load_scenes(file_path)
    updated_scenes = [scene for scene in scenes if scene["name"] != name]

    if len(scenes) == len(updated_scenes):
        print(f"⚠️ Scene '{name}' not found.")
        return False

    save_scenes(updated_scenes, file_path)
    print(f"🗑️ Scene '{name}' deleted.")
    return True

def get_scene(name, file_path=SCENES_FILE):
    scenes = load_scenes(file_path)
    for scene in scenes:
        if scene["name"] == name:
            return scene
    print(f"⚠️ Scene '{name}' not found.")
    return None

def add_scene(name, device_states, file_path=SCENES_FILE):
    scenes = load_scenes(file_path)

    if any(scene["name"] == name for scene in scenes):
        print(f"⚠️ Scene '{name}' already exists.")
        return False

    new_scene = {
        "name": name,
        "devices": device_states  # Expecting: { "device_id": {"color": {...}, "power": ..., "brightness": ...} }
    }

    scenes.append(new_scene)
    save_scenes(scenes, file_path)
    print(f"✅ Scene '{name}' added.")
    return True

def apply_scene(scene_name, send_mqtt_command, file_path=SCENES_FILE):
    scene = get_scene(scene_name, file_path)
    if not scene:
        return False

    for device_id, state in scene["devices"].items():
        desired_power = str(state.get("power", "OFF")).strip().upper()

        if desired_power == "OFF":
            send_mqtt_command(device_id, "OFF", "POWER")
            time.sleep(0.1)

        elif desired_power == "ON":
            # 1. Turn on
            send_mqtt_command(device_id, "ON", "POWER")
            time.sleep(0.1)

            # 2. Set color
            color = state.get("color")
            if color:
                rgb_str = f"{color['r']},{color['g']},{color['b']}"
                send_mqtt_command(device_id, rgb_str, "COLOR")
                time.sleep(0.1)

            # 3. Set brightness
            brightness = state.get("brightness")
            if brightness is not None:
                send_mqtt_command(device_id, str(brightness), "DIMMER")
                time.sleep(0.1)

    return True






