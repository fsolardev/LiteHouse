import json
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish

# Load settings.json for broker and device details
with open("settings.json", "r") as file:
    settings = json.load(file)

# MQTT Broker settings
MQTT_BROKER = settings["mqtt"]["broker"]
MQTT_PORT = settings["mqtt"]["port"]
MQTT_KEEPALIVE = settings["mqtt"].get("keepalive", 60)
MQTT_USER = settings["mqtt"].get("username", "")
MQTT_PASS = settings["mqtt"].get("password", "")

# Initialize MQTT Client
mqtt_client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT.")
    else:
        print(f"Failed to connect to MQTT: {rc}")

def on_disconnect(client, userdata, rc):
    print("Disconnected from MQTT.")

def initialize_mqtt_client():
    """Start MQTT client."""
    mqtt_client.on_connect = on_connect
    mqtt_client.on_disconnect = on_disconnect
    try:
        if MQTT_USER and MQTT_PASS:
            mqtt_client.username_pw_set(MQTT_USER, MQTT_PASS)
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, MQTT_KEEPALIVE)
        mqtt_client.loop_start()
        print("MQTT initialized successfully.")
    except Exception as e:
        print(f"MQTT initialization error: {e}")

def get_device_topic(device_id):
    """Get MQTT topic from settings.json."""
    for device in settings["devices"]:
        if device["id"] == device_id:
            return device["topic"]
    return None

def send_mqtt_command(device_id, command, command_type=None):
    topic = get_device_topic(device_id)
    device_info = next((d for d in settings["devices"] if d["id"] == device_id), None)

    if not topic or not device_info:
        print(f"Device '{device_id}' not found.")
        return False

    device_type = device_info["type"]

    try:
        # WLED — JSON via /api
        if device_type == "WLED":
            full_topic = f"{topic}/api"
            if command_type == "POWER":
                payload = '{"on":true}' if str(command).lower() in ['1', 'on', 'true'] else '{"on":false}'
            elif command_type == "COLOR":
                r, g, b = map(int, command.split(','))
                payload = f'{{"seg":[{{"col":[[{r},{g},{b}]]}}]}}'
            elif command_type == "DIMMER":
                brightness = int(command)
                payload = f'{{"bri":{brightness}}}'
            else:
                print("Unsupported WLED command type.")
                return False

        # Tasmota2 — Tasmota-compatible topics
        elif device_type == "Tasmota2":
            if command_type == "POWER":
                full_topic = f"{topic}/Power"
                payload = command
            elif command_type == "COLOR":
                full_topic = f"{topic}/Color"
                payload = command
            elif command_type == "DIMMER":
                full_topic = f"{topic}/Dimmer"
                payload = str(command)
            else:
                return False

        # OpenBeken — hexadecimal for color
        elif device_type == "OpenBeken":
            if command_type == "POWER":
                full_topic = f"{topic}/Power"
                payload = command
            elif command_type == "COLOR":
                r, g, b = map(int, command.split(','))
                hex_color = f'{r:02x}{g:02x}{b:02x}'
                full_topic = f"{topic}/led_basecolor_rgb"
                payload = hex_color
            elif command_type == "DIMMER":
                full_topic = f"{topic}/led_dimmer"
                payload = str(command)
            else:
                return False

        else:
            return False

        # Publish message
        auth = {'username': MQTT_USER, 'password': MQTT_PASS} if MQTT_USER else None
        publish.single(full_topic, payload, hostname=MQTT_BROKER, port=MQTT_PORT, auth=auth)
        print(f"MQTT SENT → {full_topic}: {payload}")
        return True

    except Exception as e:
        print(f"MQTT error: {e}")
        return False
