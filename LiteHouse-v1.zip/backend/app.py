from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import requests
from mqtt_handler import send_mqtt_command, initialize_mqtt_client
from main import load_scenes, add_scene, delete_scene, apply_scene, get_scene

# Load settings
import json
with open("settings.json") as f:
    settings = json.load(f)

# Flask setup
app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

# Initialize MQTT
initialize_mqtt_client()

# global device status
device_status = {
  "openbeken_device": {
    "color": "255,46,126",
    "power": "ON"
  },
  "tasmota2_device": {
    "color": "255,46,126",
    "power": "ON"
  },
  "wled_device": {
    "color": "255,46,126",
    "power": "ON"
  }
}

# ✅ API: Get device status (power + color)
@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify(device_status)

# ✅ API: Control devices
@app.route('/api/control', methods=['POST'])
def control():
    data = request.json
    device = data.get('device')
    command = data.get('command')
    command_type = data.get('command_type')

    if not device or command is None:
        return jsonify({'error': 'Invalid data'}), 400

    success = send_mqtt_command(device, command, command_type)
    
    # update status
    status = device_status[device]
    if not status:
        status = {"power": 0,
            "color": ""}
    if command_type == "POWER":
        status["power"] = "OFF" if status["power"] == "ON" else "ON"
    elif command_type == "COLOR":
        status["color"] = command
    device_status[device] = status
            
    return jsonify({'success': success})

@app.route('/api/scenes', methods=['GET'])
def get_scenes():
    return jsonify(load_scenes())

@app.route('/api/scenes', methods=['POST'])
def create_scene():
    data = request.json
    name = data.get('name')
    devices = data.get('devices')  # full device state

    if not name or not devices:
        return jsonify({'error': 'Invalid data'}), 400

    if add_scene(name, devices):
        return jsonify({'success': True}), 201
    else:
        return jsonify({'error': 'Scene already exists'}), 409

# ✅ API: Delete scene
@app.route('/api/scenes/<string:name>', methods=['DELETE'])
def remove_scene(name):
    if delete_scene(name):
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'Scene not found'}), 404

# ✅ API: Apply scene
@app.route('/api/apply_scene', methods=['POST'])
def apply_scene_api():
    data = request.json
    scene_name = data.get("scene_name")

    if not scene_name:
        return jsonify({"error": "Scene name is required"}), 400

    scene = get_scene(scene_name)
    if not scene:
        return jsonify({"error": f"Scene '{scene_name}' not found"}), 404

    success = apply_scene(scene_name, send_mqtt_command)

    if success:
        for device_id, state in scene["devices"].items():
            color = state.get("color", {"r": 255, "g": 255, "b": 255})
            power = state.get("power", "OFF")

            device_status[device_id] = {
                "color": f"{color['r']},{color['g']},{color['b']}",
                "power": power
            }

        return jsonify({"success": True, "devices": scene["devices"]})
    else:
        return jsonify({"error": f"Scene '{scene_name}' not found"}), 404

# ✅ Health check
@app.route('/api/ping', methods=['GET'])
def ping():
    return jsonify({"status": "API is running"}), 200

# ✅ Serve frontend
@app.route('/')
def serve_frontend():
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
